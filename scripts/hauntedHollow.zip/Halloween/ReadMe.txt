You should maintain the disk structure of the application.  To change the click event target (where you
branch to when an object is clicked),  navigate to the ../Halloween/HauntedHollow/js directory and open
the file HalloweenV5.js with an editor (notepad will work).

Find the following entry (somewhere around line number 17:

	  var storeURL      = '../Projects/index.html#HauntedHollow';

Change the storeURL entry to match your desired target.

